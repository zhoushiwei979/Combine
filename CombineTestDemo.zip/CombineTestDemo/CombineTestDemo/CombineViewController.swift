//
//  CombineViewController.swift
//  CombineTestDemo
//
//  Created by 周诗玮 on 2024/11/22.
//

import UIKit
import Combine

///
class CombineViewController: UIViewController {

    ///
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        test()
        test_a()
        test_b()
        test_c()
        test_d()
        test_e()
        test_f()
        test_g()
        test_h()
        test_i()
        test_j()
        test_k()
        test_l()
        test_m()
        test_n()
        test_o()
        test_p()
        test_q()
        test_r()
        test_s()
        test_t()
    }
}

// MARK: - Publisher（发布者）
extension CombineViewController {
    func test_a() {
        let publisher = Just(5)
        _ = publisher.sink(receiveCompletion: { print($0) }, receiveValue: { print($0) })
    }
}

// MARK: - Subscriber（订阅者）
extension CombineViewController {
    func test_b() {
        let publisher = Just("Hello, Combine")
        _ = publisher.sink(
            receiveCompletion: { value in print("Completion: \(value)") },
            receiveValue: { value in print("Value: \(value)") }
        )
    }
}

// MARK: - Subscription（订阅）
final class CustomSubscriber: Subscriber {
    func receive(subscription: Subscription) {
        print("Subscribed!")
        subscription.request(.max(3)) // 只请求3个值
    }

    func receive(_ input: Int) -> Subscribers.Demand {
        print("Received value: \(input)")
        return .none // 不请求更多值
    }

    func receive(completion: Subscribers.Completion<Never>) {
        print("Completed")
    }
}

// MARK: - Subject（主题）
extension CombineViewController {
    func test_c() {
        let subject = PassthroughSubject<String, Never>()
        _ = subject.sink { value in
            print("Received value: \(value)")
        }
        subject.send("Hello")
        subject.send("World")
    }
}

// MARK: - 操作符 Operators

// MARK: - Transforming Operators（转换操作符）
extension CombineViewController {
    
    // map：将发布者发出的值进行映射，转换成另一个类型的值。
    func test_d() {
        let numbers = [1, 2, 3, 4]
        let publisher = numbers.publisher
        _ = publisher
            .map { $0 * 2 }
            .sink { value in
                print(value) // 输出：2, 4, 6, 8
            }
    }
    
    // compactMap：类似于 map，但可以过滤掉 nil 值，只返回非空值。
    func test_e() {
        let numbers = ["1", "2", "a", "4"]
        let publisher = numbers.publisher
        _ = publisher
            .compactMap { Int($0) } // 尝试将字符串转换为 Int，忽略不能转换的值
            .sink { print($0) }
    }
    
    // flatMap：用于将每个元素映射到一个新的发布者，然后将这些发布者的元素合并成一个新的发布者。
    func test() {
        let publisher = [1, 2, 3].publisher
        _ = publisher.flatMap { value in
            Just(value * 2)
        }
        .sink { value in
            print(value) // 输出：2, 4, 6
        }
    }
}

// MARK: - Filtering Operators（过滤操作符）
extension CombineViewController {
    
    // filter：只通过满足条件的值，过滤掉不符合条件的元素。
    func test_f() {
        let numbers = [1, 2, 3, 4, 5]
        let publisher = numbers.publisher
        _ = publisher.filter { $0 % 2 == 0 }
            .sink { value in
                print(value) // 输出：2, 4
            }
    }
    
    // removeDuplicates：移除连续重复的值。
    func test_g() {
        let numbers = [1, 1, 2, 3, 3, 3, 4]
        let publisher = numbers.publisher
        _ = publisher
            .removeDuplicates() // 移除连续重复的值
            .sink { print($0) }
    }
}

// MARK: - Combining Operators（组合操作符）
extension CombineViewController {
    
    // merge：将两个或多个发布者的输出合并成一个流。
    func test_h() {
        // 例子1
        let publisher1 = PassthroughSubject<Int, Never>()
        let publisher2 = PassthroughSubject<Int, Never>()

        _ = Publishers.Merge(publisher1, publisher2)
                  .sink { value in
                      print(value)
                  }
        publisher1.send(1)
        publisher2.send(2) // 输出：1, 2
        
        // 例子2
        let pub1 = [1, 2, 3].publisher
        let pub2 = [4, 5, 6].publisher
        _ = pub1
            .merge(with: pub2) // 将两个发布者的值合并
            .sink { print($0) }
    }
    
    // combineLatest：当两个或多个发布者都发出值时，组合它们的最新值。
    func test_i() {
        // 例子1
        let publisher1 = PassthroughSubject<Int, Never>()
        let publisher2 = PassthroughSubject<String, Never>()

        _ = publisher1.combineLatest(publisher2)
                   .sink { value in
                       print(value)
                   }

        publisher1.send(1)
        publisher2.send("A") // 输出：(1, "A")
        
        // 例子2
        let pub1 = PassthroughSubject<Int, Never>()
        let pub2 = PassthroughSubject<String, Never>()
        _ = pub1
            .combineLatest(pub2) // 组合最新的值
            .sink { value in print("pub1: \(value.0), pub2: \(value.1)") }
    }
    
    // zip：与 combineLatest 类似，但它只会在两个发布者都有值时才会发出值，并且会按照顺序组合。
    func test_j() {
        let pub1 = [1, 2, 3].publisher
        let pub2 = ["a", "b", "c"].publisher
        _ = pub1
            .zip(pub2) // 按顺序组合两个发布者的值
            .sink { print($0, $1) }
    }
}

// MARK: - Timing Operators（时间操作符）
extension CombineViewController {
    
    // debounce：延迟发出值，直到指定时间段内没有新的值发出。
    func test_k() {
        let subject = PassthroughSubject<String, Never>()
        _ = subject
            .debounce(for: .seconds(1), scheduler: DispatchQueue.main) // 1秒内没有值发出才进行发射
            .sink { print($0) }
    }
    
    // delay：延迟发布者的输出。
    func test_l() {
        let publisher = Just("Hello")
        _ = publisher
            .delay(for: .seconds(2), scheduler: DispatchQueue.main) // 延迟2秒后发出值
            .sink { print($0) }
    }
}

// MARK: - Error Handling Operators（错误处理操作符）
extension CombineViewController {
    
    // catch：处理发布者在发出错误时，返回一个新的发布者。
    func test_m() {
        let publisher = Fail<Int, Error>(error: NSError(domain: "", code: -1, userInfo: nil))
        _ = publisher
            .catch { _ in Just(100) } // 捕获错误并返回一个默认值
            .sink { print($0) }
    }
    
    // retry：如果发布者遇到错误，可以重新尝试订阅指定次数。
    func test_n() {
        let publisher = Fail<Int, Error>(error: NSError(domain: "", code: -1, userInfo: nil))
        _ = publisher
            .retry(3) // 遇到错误时最多重试3次
            .sink(receiveCompletion: { _ in }, receiveValue: { print($0) })
    }
}

// MARK: - Reducing Operators（归约操作符）
extension CombineViewController {
    
    // reduce：累积值，直到发布者完成并发出最终结果。
    func test_o() {
        let numbers = [1, 2, 3, 4]
        let publisher = numbers.publisher
        _ = publisher
            .reduce(0) { $0 + $1 } // 累加所有的值
            .sink { print($0) }
    }
    
    // scan：类似于 reduce，但会在每个新值到达时发出中间结果。
    func test_p() {
        // 例子1
        let numbers = [1, 2, 3, 4]
        let publisher = numbers.publisher
        _ = publisher
            .scan(0) { $0 + $1 } // 累加值并发出中间结果
            .sink { print($0) }
        
        // 例子2
        let publisher_1 = [1, 2, 3].publisher
        _ = publisher_1.scan(0) { accumulator, value in
            accumulator + value
        }
        .sink { value in
            print(value) // 输出：1, 3, 6
        }
    }
}

// MARK: - 高阶 Scheduler
extension CombineViewController {
    
    // 在后台线程执行网络请求，主线程更新 UI
    func test_q() {
        guard let url = URL(string: "https://example.com") else { return }
        _ = URLSession.shared.dataTaskPublisher(for: url)
            .subscribe(on: DispatchQueue.global(qos: .background)) // 在后台执行网络请求
            .receive(on: DispatchQueue.main) // 在主线程接收并更新 UI
            .sink(receiveCompletion: { completion in
                print("Request completed: \(completion)")
            }, receiveValue: { data, response in
                print("Data received: \(data)")
            })
    }
    
    // 延迟任务执行
    func test_r() {
        _ = Just("Hello")
            .delay(for: .seconds(3), scheduler: DispatchQueue.main) // 延迟3秒后执行
            .sink { value in
                print("Received after delay: \(value)")
            }
    }
    
    // 频繁计算任务调度
    func test_s() {
        _ = Just("Search Query")
            .receive(on: RunLoop.main) // 在主线程的事件循环中进行
            .sink { value in
                print("Received on RunLoop: \(value)")
            }
    }
    
    // 避免主线程阻塞
    func test_t() {
        _ = Just(42)
            .map { value in
                // 执行一些耗时的计算
                return (0..<1000000).reduce(value, +)
            }
            .subscribe(on: DispatchQueue.global(qos: .userInitiated)) // 在后台线程执行计算
            .receive(on: DispatchQueue.main) // 在主线程更新 UI
            .sink { result in
                print("Computation result: \(result)")
            }
    }
}

// MARK: - 一个简单的例子，演示了 Combine 中的一些概念
class combineTestFirst {
    func test() {
        
        // 创建一个发布者，发出一系列整数
        let publisher = [1, 2, 3, 4, 5].publisher

        // 订阅者，处理发布者发出的事件
        _ = Subscribers.Sink<Int, Never>(receiveCompletion: { _ in
            
        }, receiveValue: { value in
            print("Received value: \(value)")
        })

        // 订阅发布者
        let cancellable = publisher.sink(receiveValue: { value in
            print("Received value: \(value)")
        })

        // 取消订阅
        cancellable.cancel()
    }
}

